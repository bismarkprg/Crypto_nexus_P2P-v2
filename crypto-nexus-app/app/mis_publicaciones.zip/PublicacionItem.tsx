
"use client";

import api from "@/lib/api";

export default function PublicacionItem({ data, onCancel }: any) {

  const cancelarPublicacion = async () => {
    if (!confirm("¿Cancelar esta publicación?")) return;

    try {
      await api.put(`/p2p/cancelar_publicacion/${data.id_publicacion}`);
      onCancel();
    } catch (error) {
      console.error("Error cancelando publicación:", error);
    }
  };

  return (
    <tr>
      <td>{data.fecha_publicacion}</td>

      <td>Bs. {Number(data.precio_venta_bob).toFixed(2)}</td>

      <td>
        {data.minimo_compra} BOB – {data.maximo_compra} BOB
      </td>

      <td>
        <button className="btn-eliminar" onClick={cancelarPublicacion}>
          🗑
        </button>
      </td>
    </tr>
  );
}
